package airlift.app;

@javax.annotation.Generated
(
	value="airlift.generator.Generator",
	comments="",
	date = ""
)

public class AppProfile
   implements airlift.AppProfile
{
	public static final java.util.Map<String, java.util.Map<String, java.util.Set<String>>> resourceSecurityMetadataMap = new java.util.HashMap<String, java.util.Map<String, java.util.Set<String>>>();
	public static final java.util.Map<String, String> viewMap = new java.util.HashMap<String, String>();
	public static final java.util.Set<String> viewSet = new java.util.HashSet<String>();
	
	static
	{
		
		resourceSecurityMetadataMap.put("runner", new java.util.HashMap<String, java.util.Set<String>>()); 
		resourceSecurityMetadataMap.put("race", new java.util.HashMap<String, java.util.Set<String>>()); 

			
	}

	public AppProfile() {}

	public String appName = "analytics-web";
	
	public String getAppName()
	{
		return appName;
	}

	public boolean isView(String _resourceName)
	{
		return viewSet.contains(_resourceName.toLowerCase());
	}

	public String getLookingAt(String _resourceName)
	{
		return viewMap.get(_resourceName.toLowerCase());
	}
	
	public java.util.Set<String> getValidResources()
	{
		return resourceSecurityMetadataMap.keySet();
	}

	public boolean isValidResource(String _resourceName)
	{
		return resourceSecurityMetadataMap.keySet().contains(_resourceName.toLowerCase());
	}

	public java.util.Map<String, java.util.Set<String>> getSecurityRoles(String _resourceName)
	{
		return resourceSecurityMetadataMap.get(_resourceName);
	}
}