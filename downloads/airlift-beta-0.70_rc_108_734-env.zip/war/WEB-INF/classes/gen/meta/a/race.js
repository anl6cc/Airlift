var MetaData = function()
{
	this.resourceName = 'race';
	this.attributes = {};

	var metadata = require('airlift/AttributeMetadata');
	this.attributes['name'] = metadata.create({ name:"name", type:"java.lang.String", displayOrder:10, label:"name" }); 
	this.attributes['distance'] = metadata.create({ name:"distance", type:"java.lang.Double", displayOrder:20, label:"distance" }); 
	this.attributes['auditPostDate'] = metadata.create({ name:"auditPostDate", type:"java.util.Date", isSearchable:true, isIndexable:true, required:false, label:"record created date" }); 
	this.attributes['auditPutDate'] = metadata.create({ name:"auditPutDate", type:"java.util.Date", isSearchable:true, isIndexable:true, required:false, label:"record updated date" }); 
	this.attributes['auditUserId'] = metadata.create({ name:"auditUserId", type:"java.lang.String", isSearchable:true, isIndexable:true, required:false, label:"changed by user id", isPresentable:false }); 
	this.attributes['auditRequestId'] = metadata.create({ name:"auditRequestId", type:"java.lang.String", isSearchable:true, isIndexable:true, required:false, label:"web request id", isPresentable:false }); 
	this.attributes['id'] = metadata.create({ name:"id", type:"java.lang.String", isSearchable:false, isPrimaryKey:true, isIndexable:false, required:false, displayOrder:0, label:"record id" }); 
}

exports.create = function()
{
	return new MetaData();
};