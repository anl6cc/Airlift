var MetaData = function()
{
	this.resourceName = 'runner';
	this.attributes = {};

	var metadata = require('airlift/AttributeMetadata');
	this.attributes['name'] = metadata.create({ name:"name", type:"java.lang.String", displayOrder:10, label:"name" }); 
	this.attributes['bibNumber'] = metadata.create({ name:"bibNumber", type:"java.lang.String", displayOrder:20, label:"bib number" }); 
	this.attributes['race'] = metadata.create({ name:"race", type:"java.lang.String", mapTo:"race", isIndexable:true, displayOrder:30, label:"race" }); 
	this.attributes['auditPostDate'] = metadata.create({ name:"auditPostDate", type:"java.util.Date", isSearchable:true, isIndexable:true, required:false, label:"record created date" }); 
	this.attributes['auditPutDate'] = metadata.create({ name:"auditPutDate", type:"java.util.Date", isSearchable:true, isIndexable:true, required:false, label:"record updated date" }); 
	this.attributes['auditUserId'] = metadata.create({ name:"auditUserId", type:"java.lang.String", isSearchable:true, isIndexable:true, required:false, label:"changed by user id", isPresentable:false }); 
	this.attributes['auditRequestId'] = metadata.create({ name:"auditRequestId", type:"java.lang.String", isSearchable:true, isIndexable:true, required:false, label:"web request id", isPresentable:false }); 
	this.attributes['id'] = metadata.create({ name:"id", type:"java.lang.String", isSearchable:false, isPrimaryKey:true, isIndexable:false, required:false, displayOrder:0, label:"record id" }); 
}

exports.create = function()
{
	return new MetaData();
};