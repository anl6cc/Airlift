exports.handle = function(_web)
{
	require('../../..airliftGit2/Airlift/src/script/javascript/airlift/rest/put').put(_web);
};
