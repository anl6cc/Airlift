exports.handle = function(_web)
{
	require('airlift/rest/get').get(_web);
};
