exports.handle = function(_web)
{
	require('airlift/rest/collect').collect(_web);
};
