exports.handle = function(_web)
{
	require('airlift/rest/post').post(_web);
}
