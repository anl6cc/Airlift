exports.handle = function(_web)
{
	var htmlRenderer = function(_resource)
	{
		var html = '<html><body><ul>';
		var res = require('airlift/resource').create(_web);
		
		return res.reduce(html, 'runner', _resource, function(_base, _value, _name) //per attribute
			{
				return _base + '<li><span>' + _name + '</span>: <span>' + _value + '</span></li>';
			},
			function() //at the end of the iteration
			{
				html += '</ul></body></html>';
			});
	}
	require('airlift/rest/get').get(_web, {resourceSerializer: htmlRenderer});
};
