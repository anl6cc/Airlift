exports.handle = function(_web, _config)
{
	var da = require('airlift/da/collect').create(_web);
	var res = require('airlift/resource').create(_web);
	var config = _config||{};
	var collection = da.collect(config.resourceName || _web.getResourceName(), config);

	var html = "<html><body>";

	for (var resource in Iterator(collection))
	{
		html += "<ul>";
		html += res.reduce('', 'runner', resource, function(_base, _value, _name) //per attribute
			{
				return _base + '<li><span>' + _name + '</span>: <span>' + _value + '</span></li>';
			});	html += "</ul>";
	}

	html += "</body></html>";

	_web.setContent(html);
	
};
